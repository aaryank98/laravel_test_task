<?php $__env->startSection('content'); ?>

<section class="bg-slate-200 h-20">
    <div class="container mx-auto">
        <div class="flex flex-row justify-between">
            <h1 class="text-2xl py-5">Add Property</h1>
        </div>
    </div>
</section>

<section class="my-10">
    <div class="container mx-auto">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="py-1 text-rose-600"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php echo e(Form::open(['route' => 'properties.store'])); ?>

        <div class="space-y-12">
            <div class="">
                <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
                    <div class="col-span-3">
                        <?php echo Form::label('county', 'County', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::text('county', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5 ']); ?>

                        </div>
                    </div>

                    <div class="col-span-3">
                        <?php echo Form::label('country', 'Country', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::text('country', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5 ']); ?>

                        </div>
                    </div>

                    <div class="col-span-3">
                        <?php echo Form::label('town', 'Town', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::text('town', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5 ']); ?>

                        </div>
                    </div>

                    <div class="col-span-3">
                        <?php echo Form::label('postcode', 'Postcode', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::text('postcode', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5 ']); ?>

                        </div>
                    </div>


                    <div class="col-span-full">
                        <?php echo Form::label('description', 'Description', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::textarea('description', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5', 'rows' => 3]); ?>

                        </div>
                    </div>

                    <div class="col-span-3">
                        <?php echo Form::label('address', 'Displayable Address', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::text('address', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5 ']); ?>

                        </div>
                    </div>


                    <div class="col-span-3">
                        <?php echo Form::label('num_bedrooms', 'Number of bedrooms', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::select('num_bedrooms', [1,2,3,4,5,6,7,8,9,10], 1, ['class'=>'w-full rounded-md border-2 px-2 py-2 bg-white']); ?>

                        </div>
                    </div>


                    <div class="col-span-3">
                        <?php echo Form::label('num_bathrooms', 'Number of bathrooms', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::select('num_bathrooms', [1,2,3,4,5,6,7,8,9,10], 1, ['class'=>'w-full rounded-md border-2 px-2 py-2 bg-white']); ?>

                        </div>
                    </div>

                    <div class="col-span-3">
                        <?php echo Form::label('price', 'Price', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::text('price', '',['class' => 'w-full rounded-md border-2 px-2 py-1.5 ']); ?>

                        </div>
                    </div>


                    <div class="col-span-3">
                        <?php echo Form::label('property_type_id', 'Property Type', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::select('property_type_id', [1,2,3,4,5,6,7,8,9,10], 1, ['class'=>'w-full rounded-md border-2 px-2 py-2 bg-white']); ?>

                        </div>
                    </div>


                    <div class="col-span-1">
                        <?php echo Form::label('property_for', 'For Sale / For Rent ', ['class'=>'block text-sm font-medium leading-6 text-gray-900']); ?>

                        <div class="mt-2">
                            <?php echo Form::radio('property_for', 'sale', '', ['class'=>'inline-block h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-600']); ?>

                            <?php echo Form::label('property_for', 'Sale ', ['class'=>'inline-block text-sm font-medium text-gray-900']); ?>


                            <?php echo Form::radio('property_for', 'rent', '', ['class'=>'inline-block h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-600']); ?>

                            <?php echo Form::label('property_for', 'Rent ', ['class'=>'inline-block text-sm font-medium text-gray-900']); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-6 flex items-center justify-end gap-x-6">
            <button type="button" class="text-sm font-semibold leading-6 text-gray-900">Cancel</button>
            <?php echo Form::submit('Save', ['class' => 'rounded-md bg-gray-800 px-3 py-2 text-sm text-white hover:bg-gray-500']); ?>

        </div>
        <?php echo e(Form::close()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-test/resources/views/properties/add.blade.php ENDPATH**/ ?>