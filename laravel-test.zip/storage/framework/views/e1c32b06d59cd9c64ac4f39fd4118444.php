<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('content'); ?>

<p>This is my body content.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-test/resources/views/list.blade.php ENDPATH**/ ?>